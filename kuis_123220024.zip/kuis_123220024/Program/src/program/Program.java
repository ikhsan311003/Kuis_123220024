package program;

import javax.swing.*;
import java.awt.event.*;

public class Program extends JFrame {

private String namaKategoriAnimasi;
private String asalSekolahKategoriAnimasi;
private String namaKategoriMenulisSurat;
private String asalSekolahKategoriMenulisSurat;

private JRadioButton kategoriAnimasiRadioButton;
private JRadioButton kategoriMenulisSuratRadioButton;
private JTextField namaField;
private JTextField asalSekolahField;
private JButton simpanButton;
private JTextField alurCeritaField;
private JTextField kontenField;
private JTextField kreativitasField;
private JTextField sinematografiField;
private JTextField strukturSuratField;
private JTextField isiSuratField;
private JTextField kreativitassField;
private JTextField penerapanKaidahBahasaField;

public Program(){
    initComponents();
}

private void initComponents(){
namaField = new JTextField(30);
asalSekolahField = new JTextField(30);
kategoriAnimasiRadioButton = new JRadioButton("Animasi");
kategoriMenulisSuratRadioButton = new JRadioButton("Menulis Surat");
simpanButton = new JButton("Simpan");
ButtonGroup group = new ButtonGroup();
group.add(kategoriAnimasiRadioButton);
group.add(kategoriMenulisSuratRadioButton);
simpanButton.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent evt) {
simpanButtonActionPerformed(evt);
}
});

setTitle("PERLOMBAAN ANTAR SMA");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setSize(800, 400);
setLocationRelativeTo(null);

 JPanel panel = new JPanel();
 panel.add(new JLabel("Nama Peserta :"));
 panel.add(namaField);
 panel.add(new JLabel("Asal Sekolah :"));
 panel.add(asalSekolahField);
 panel.add(new JLabel("Jenis Perlombaan :"));
 panel.add(kategoriAnimasiRadioButton);
 panel.add(kategoriMenulisSuratRadioButton);
 panel.add(new JLabel("Input Nilai Kategori Lomba Animasi :"));

 panel.add(new JLabel("Input Nilai Kategori Lomba Menulis Surat :"));
 panel.add(new JLabel("Struktur Surat :"));
 panel.add(strukturSuratField);
 panel.add(new JLabel("Isi Surat :"));
 panel.add(isiSuratField);
 panel.add(new JLabel("Kreativitas :"));
 panel.add(kreativitassField);
 panel.add(new JLabel("Penerapan Kaidah Bahasa :"));
 panel.add(penerapanKaidahBahasaField);
 panel.add(simpanButton);
 add(panel);
 }

private void simpanButtonActionPerformed(ActionEvent evt) { 
    if (!kategoriAnimasiRadioButton.isSelected() && !kategoriMenulisSuratRadioButton.isSelected()) {
            JOptionPane.showMessageDialog(null, "Pilih Kategori Perlombaan Terlebih Dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String kategoriDipilih = "";

        if (kategoriAnimasiRadioButton.isSelected()) {
            kategoriAnimasiFrame kategoriAnimasiFrame = new kategoriAnimasiFrame();
            kategoriAnimasiFrame.setVisible(true);
            dispose();
        } else if (kategoriMenulisSuratRadioButton.isSelected()) {
            kategoriMenulisSuratFrame kategoriMenulisSuratFrame = new kategoriMenulisSuratFrame();
            kategoriMenulisSuratFrame.setVisible(true);
            dispose(); 
        }
}
    public static void main(String args[]) {
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Program().setVisible(true);
            }
        });
    }
}

class kategoriAnimasiFrame extends JFrame {
    private JTextField alurCeritaField;
    private JTextField kontenField;
    private JTextField kreativitasField;
    private JTextField sinematografiField;

    public kategoriAnimasiFrame() {
        initComponents();
    }

    private void initComponents() {
        alurCeritaField = new JTextField(20);
        kontenField = new JTextField(20);
        kreativitasField = new JTextField(20);
        sinematografiField = new JTextField(20);
        JButton okButton = new JButton("OK");

        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                okButtonActionPerformed(evt);
            }
        });

        setTitle("Input Nilai Kategori Animasi");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.add(new JLabel("Input Nilai :"));
        panel.add(new JLabel("Alur Cerita :"));
        panel.add(alurCeritaField);
        panel.add(new JLabel("Konten :"));
        panel.add(kontenField);
        panel.add(new JLabel("Kreativitas :"));
        panel.add(kreativitasField); 
        panel.add(new JLabel("Sinematografi :"));
        panel.add(sinematografiField);
        panel.add(okButton);

        add(panel);
    }
    private void okButtonActionPerformed(ActionEvent evt) {
        double nilai = 0;
        String kategori = "";
        if (alurCeritaField.isValid()) {
            nilai = 15/100; 
            kategori = "Alur Cerita";
        } else if (kontenField.isValid()) {
            nilai = 35/100; 
            kategori = "Konten";
        } else if (kreativitasField.isValid()) {
            nilai = 15/100; 
            kategori = "Kreativitas";
        }

        String message = "Total:\n\n"
                + "Jenis Kategori: " + kategori + "\n"
                + "Nilai:  " + nilai + "\n";

        JOptionPane.showMessageDialog(null, message, "Detail Penyewaan", JOptionPane.INFORMATION_MESSAGE);
        dispose(); 
    }
}

